#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

#include <unistd.h>


void append(pid_t p, char** command);
void deleting(pid_t p);
void print_list();

#endif
